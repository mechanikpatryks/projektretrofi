package com.example.projektretrofit;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

// interfejs do pobierania danych
public interface JsonPlaceHolderApi {

    // pobieranie pliku ksiazki.json
    @GET("ksiazki.json")
    Call<List<Ksiazka>> getKsiazki();
}
