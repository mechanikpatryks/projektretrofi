package com.example.projektretrofit;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // znalezienie listy w widoku
        listView = findViewById(R.id.listView);

        // tworzenie obiektu Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://raw.githubusercontent.com/mechanikpatryks/projektretrofi/refs/heads/main/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        // utworzenie interfejsu
        JsonPlaceHolderApi jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);

        // wywolanie zapytania
        Call<List<Ksiazka>> call = jsonPlaceHolderApi.getKsiazki();

        // pobieranie danych w tle
        call.enqueue(new Callback<List<Ksiazka>>() {
            @Override
            public void onResponse(Call<List<Ksiazka>> call, Response<List<Ksiazka>> response) {
                // sprawdzam czy odpowiedz jest poprawna
                if (!response.isSuccessful()) {
                    Toast.makeText(MainActivity.this,
                            "Błąd: " + response.code(), Toast.LENGTH_LONG).show();
                    return;
                }

                // pobieram liste ksiazek
                List<Ksiazka> ksiazki = response.body();

                // ustawiam adapter na liscie
                if (ksiazki != null) {
                    KsiazkaAdapter adapter = new KsiazkaAdapter(MainActivity.this, ksiazki);
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<List<Ksiazka>> call, Throwable t) {
                // błąd połączenia
                Toast.makeText(MainActivity.this,
                        "Brak połączenia: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
