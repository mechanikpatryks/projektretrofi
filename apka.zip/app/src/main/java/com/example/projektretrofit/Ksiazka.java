package com.example.projektretrofit;

import com.google.gson.annotations.SerializedName;

// klasa reprezentujaca ksiazke
public class Ksiazka {

    private int id;
    private String tytul;
    private String autor;

    // mapowanie nazwy pola z jsona
    @SerializedName("rok_wydania")
    private int rokWydania;

    public Ksiazka(int id, String tytul, String autor, int rokWydania) {
        this.id = id;
        this.tytul = tytul;
        this.autor = autor;
        this.rokWydania = rokWydania;
    }

    public int getId() {
        return id;
    }

    public String getTytul() {
        return tytul;
    }

    public String getAutor() {
        return autor;
    }

    public int getRokWydania() {
        return rokWydania;
    }
}
