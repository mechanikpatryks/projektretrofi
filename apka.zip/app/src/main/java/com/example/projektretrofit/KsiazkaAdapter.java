package com.example.projektretrofit;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

// adapter do wyswietlania listy ksiazek
public class KsiazkaAdapter extends ArrayAdapter<Ksiazka> {

    public KsiazkaAdapter(@NonNull Context context, @NonNull List<Ksiazka> ksiazki) {
        super(context, 0, ksiazki);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        // tworzenie widoku elementu jesli jeszcze nie istnieje
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_ksiazka, parent, false);
        }

        // pobranie ksiazki dla danej pozycji
        Ksiazka ksiazka = getItem(position);

        // znalezienie pol tekstowych
        TextView tvTytul = convertView.findViewById(R.id.tvTytul);
        TextView tvAutor = convertView.findViewById(R.id.tvAutor);
        TextView tvRok = convertView.findViewById(R.id.tvRok);

        // wpisanie danych do pol
        if (ksiazka != null) {
            tvTytul.setText(ksiazka.getTytul());
            tvAutor.setText("Autor: " + ksiazka.getAutor());
            tvRok.setText("Rok wydania: " + ksiazka.getRokWydania());
        }

        return convertView;
    }
}
